<?php
class Admin_IndexController extends Zend_Controller_Action {

    public function init() {
                 $options = array(
            'layout' => 'layout',
        );
        Zend_Layout::startMvc($options);

    }
    
    public function indexAction() {
       
   	}
   
    
}

